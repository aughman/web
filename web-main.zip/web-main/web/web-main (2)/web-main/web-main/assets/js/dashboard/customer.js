import authService from '../services/auth.js';
import orderService from '../services/orders.js';
import productService from '../services/products.js';
import customerService from '../services/customers.js';
import supportService from '../services/support.js';
import notificationService from '../services/notifications.js';
import { showNotification, showLoading, hideLoading } from '../utils/helpers.js';
import { formatOrderStatus, formatDate } from '../utils/formatters.js';
<script src="../assets/js/storage.js"></script>

// Check authentication
if (!authService.isAuthenticated() || !authService.hasRole('customer')) {
  window.location.href = '/signin.html';
}

function showSection(sectionId) {
  document.querySelectorAll('.dashboard-section').forEach(section => {
    section.classList.remove('active');
  });
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.remove('active');
  });
  const targetSection = document.getElementById(sectionId);
  const targetLink = document.querySelector(`[href="#${sectionId}"]`);
  if (targetSection) targetSection.classList.add('active');
  if (targetLink) targetLink.classList.add('active');
}

// Load user name for welcome message
function loadUserName() {
  try {
    const user = authService.getUserData();
    console.log('User data:', user); // Debug log
    const userNameElement = document.getElementById('userName');
    if (userNameElement) {
      // Use the username (name field) that the user entered during signup
      if (user && user.name) {
        console.log('Setting username to:', user.name); // Debug log
        userNameElement.textContent = user.name;
      } else if (user && user.email) {
        // Fallback to email username if name not available
        const emailUsername = user.email.split('@')[0];
        console.log('Using email username:', emailUsername); // Debug log
        userNameElement.textContent = emailUsername;
      } else {
        console.log('No user data, using default'); // Debug log
        userNameElement.textContent = 'User';
      }
    } else {
      console.error('userName element not found');
    }
  } catch (error) {
    console.error('Failed to load user name:', error);
  }
}

// Load orders
async function loadOrders() {
  const container = document.getElementById('ordersList');
  const spinner = showLoading(container);
  
  try {
    const orders = await orderService.getCustomerOrders();
    hideLoading(spinner);
    
    if (!orders.length) {
      container.innerHTML = '<p>No orders found.</p>';
      return;
    }
    
    container.innerHTML = orders.map(order => `
      <div class="dashboard-card">
        <h3>Order #${order.id}</h3>
        <p><strong>Date:</strong> ${formatDate(order.createdAt)}</p>
        <p><strong>Status:</strong> ${formatOrderStatus(order.status)}</p>
        <p><strong>Total:</strong> $${order.total}</p>
        <button class="pill-btn secondary" onclick="viewOrder('${order.id}')">View Details</button>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    showNotification(error.message || 'Failed to load orders', 'error');
  }
}

// Load products
async function loadProducts() {
  const container = document.getElementById('productsList');
  const spinner = showLoading(container);
  
  try {
    const products = await productService.getProducts();
    hideLoading(spinner);
    
    if (!products.length) {
      container.innerHTML = '<p>No products found.</p>';
      return;
    }
    
    container.innerHTML = products.map(product => `
      <div class="dashboard-card">
        <img src="${product.images?.[0] || '/placeholder.jpg'}" alt="${product.name}" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 1rem;" />
        <h3>${product.name}</h3>
        <p>$${product.price}</p>
        <button class="pill-btn primary" onclick="viewProduct('${product.id}')">View Product</button>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    showNotification(error.message || 'Failed to load products', 'error');
  }
}

// Load collections
async function loadCollections() {
  const container = document.getElementById('collectionsList');
  const spinner = showLoading(container);
  
  try {
    // Load products as collections (you can customize this to load actual collections)
    const products = await productService.getProducts();
    hideLoading(spinner);
    
    if (!products.length) {
      container.innerHTML = '<p>No collections found. <a href="../index.html#collections">Browse all collections</a></p>';
      return;
    }
    
    container.innerHTML = products.map(product => `
      <div class="dashboard-card">
        <img src="${product.images?.[0] || '/placeholder.jpg'}" alt="${product.name}" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 1rem;" />
        <h3>${product.name}</h3>
        <p>$${product.price}</p>
        <button class="pill-btn primary" onclick="viewProduct('${product.id}')">View Collection</button>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    container.innerHTML = '<p>Failed to load collections. <a href="../index.html#collections">Browse all collections</a></p>';
    showNotification(error.message || 'Failed to load collections', 'error');
  }
}

// Load profile
async function loadProfile() {
  try {
    const profile = await customerService.getProfile();
    document.getElementById('profileName').value = profile.name || '';
    document.getElementById('profileEmail').value = profile.email || '';
    document.getElementById('profilePhone').value = profile.phone || '';
    document.getElementById('profileAddress').value = profile.address || '';
  } catch (error) {
    showNotification(error.message || 'Failed to load profile', 'error');
  }
}

// Save profile
function initProfileForm() {
  const profileForm = document.getElementById('profileForm');
  if (profileForm) {
    profileForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const profileData = {
        name: document.getElementById('profileName').value,
        email: document.getElementById('profileEmail').value,
        phone: document.getElementById('profilePhone').value,
        address: document.getElementById('profileAddress').value,
      };
      
      try {
        await customerService.updateProfile(profileData);
        showNotification('Profile updated successfully', 'success');
      } catch (error) {
        showNotification(error.message || 'Failed to update profile', 'error');
      }
    });
  }
}

// Load tickets
async function loadTickets() {
  const container = document.getElementById('ticketsList');
  const spinner = showLoading(container);
  
  try {
    const tickets = await supportService.getSupportHistory();
    hideLoading(spinner);
    
    if (!tickets.length) {
      container.innerHTML = '<p>No support tickets found.</p>';
      return;
    }
    
    container.innerHTML = tickets.map(ticket => `
      <div class="dashboard-card">
        <h3>${ticket.subject}</h3>
        <p><strong>Status:</strong> ${ticket.status}</p>
        <p><strong>Created:</strong> ${formatDate(ticket.createdAt)}</p>
        <button class="pill-btn secondary" onclick="viewTicket('${ticket.id}')">View</button>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    showNotification(error.message || 'Failed to load tickets', 'error');
  }
}

// Create ticket
function initCreateTicket() {
  const createTicketBtn = document.getElementById('createTicketBtn');
  if (createTicketBtn) {
    createTicketBtn.addEventListener('click', () => {
      const subject = prompt('Enter ticket subject:');
      if (!subject) return;
      
      const description = prompt('Enter ticket description:');
      if (!description) return;
      
      supportService.createTicket({ subject, description })
        .then(() => {
          showNotification('Ticket created successfully', 'success');
          loadTickets();
        })
        .catch(error => {
          showNotification(error.message || 'Failed to create ticket', 'error');
        });
    });
  }
}

// Load notifications
async function loadNotifications() {
  try {
    const count = await notificationService.getUnreadCount();
    document.getElementById('notificationBadge').textContent = count.unread || 0;
  } catch (error) {
    console.error('Failed to load notifications:', error);
  }
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  // Load user name for welcome message
  loadUserName();
  
  // Navigation
  document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const target = link.getAttribute('href').substring(1);
      showSection(target);
      
      // Load section data when switching
      if (target === 'products') loadProducts();
      if (target === 'collections') loadCollections();
      if (target === 'profile') {
        loadProfile();
        initProfileForm();
      }
      if (target === 'support') {
        loadTickets();
        initCreateTicket();
      }
    });
  });
  
  // Logout button
  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async () => {
      try {
        await authService.logout();
        showNotification('Logged out successfully', 'success');
        setTimeout(() => {
          window.location.href = '/signin.html';
        }, 500);
      } catch (error) {
        console.error('Logout error:', error);
        // Still redirect even if logout fails
        window.location.href = '/signin.html';
      }
    });
  }
  
  // Notification button
  const notificationsBtn = document.getElementById('notificationsBtn');
  if (notificationsBtn) {
    notificationsBtn.addEventListener('click', () => {
      showNotification('No new notifications', 'info');
    });
  }
  
  // Initial load
  loadOrders();
  loadNotifications();
  initProfileForm();
  initCreateTicket();
});

// Global functions
window.viewOrder = (orderId) => {
  window.location.href = `/orders/${orderId}.html`;
};

window.viewProduct = (productId) => {
  window.location.href = `/collab.html?id=${productId}`;
};

window.viewTicket = (ticketId) => {
  window.location.href = `/support/tickets/${ticketId}.html`;
};
function checkout() {
  const user = getCurrentUser();
  const cart = loadCart();
  let orders = loadOrders();
  let products = loadProducts();

  if (!cart.length) return alert("Cart is empty!");

  // Chia theo shop
  const groups = {};

  cart.forEach(item => {
    if (!groups[item.shopId]) groups[item.shopId] = [];
    groups[item.shopId].push(item);
  });

  Object.keys(groups).forEach(shopId => {
    const items = groups[shopId];

    // Lock giá + tính total
    const total = items.reduce((t, item) => t + item.price * item.qty, 0);

    orders.push({
      id: Date.now() + Math.floor(Math.random()*1000),
      customerId: user.id,
      shopId,
      items,
      total,
      status: "pending",
      createdAt: Date.now()
    });

    // Trừ stock theo code gốc
    items.forEach(i => {
      products = products.map(p =>
        p.id === i.id ? { ...p, stock: p.stock - i.qty } : p
      );
    });
  });

  saveOrders(orders);
  saveProducts(products);
  saveCart([]);

  alert("Order placed!");
  renderOrdersCustomer();
}
window.completeOrder = (id) => {
  let orders = loadOrders();
  orders = orders.map(o => o.id === id ? { ...o, status: "completed" } : o);
  saveOrders(orders);
  renderOrdersCustomer();
}

function renderOrdersCustomer() {
  const user = getCurrentUser();
  const orders = loadOrders().filter(o => o.customerId === user.id);

  document.getElementById("customerOrders").innerHTML = orders.map(o => `
    <div class="dashboard-card">
      <h3>Order #${o.id}</h3>
      <p>Total: $${o.total}</p>
      <p>Status: ${o.status}</p>
      ${o.status === "shipped" ? `<button onclick="completeOrder(${o.id})">Confirm Received</button>` : ""}
    </div>
  `).join("");
}
