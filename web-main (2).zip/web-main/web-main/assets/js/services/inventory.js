import api from './api.js';

class InventoryService {
  // INV-01: Inventory setup per product
  async setupInventory(productId, inventoryData) {
    return await api.post(`/inventory/products/${productId}`, inventoryData);
  }

  // INV-02: Stock quantity update on order
  async updateStockOnOrder(orderId) {
    return await api.post(`/inventory/orders/${orderId}/update-stock`);
  }

  // INV-04: Inventory adjustment (Shop)
  async adjustInventory(productId, adjustmentData) {
    return await api.post(`/inventory/products/${productId}/adjust`, adjustmentData);
  }

  // INV-05: Inventory reporting (Admin)
  async getInventoryReport(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/inventory/reports?${params}`);
  }

  // INV-06: Shop inventory reporting (Shop)
  async getShopInventoryReport(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/inventory/shop/reports?${params}`);
  }

  async getLowStockAlerts() {
    return await api.get('/inventory/alerts/low-stock');
  }

  async getInventoryByProduct(productId) {
    return await api.get(`/inventory/products/${productId}`);
  }
}

export default new InventoryService();

