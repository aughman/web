import api from './api.js';

class PaymentService {
  // PAY-01: Integrate payment gateway(s)
  async getPaymentGateways() {
    return await api.get('/payments/gateways');
  }

  async configureGateway(gatewayData) {
    return await api.post('/payments/gateways', gatewayData);
  }

  // PAY-02: Process customer payments
  async processPayment(paymentData) {
    return await api.post('/payments/process', paymentData);
  }

  // PAY-03: Payment status tracking
  async getPaymentStatus(paymentId) {
    return await api.get(`/payments/${paymentId}/status`);
  }

  // PAY-04: Transaction history (Shop, Admin)
  async getTransactions(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/payments/transactions?${params}`);
  }

  // PAY-05: Handle failed payments
  async retryPayment(paymentId) {
    return await api.post(`/payments/${paymentId}/retry`);
  }

  async handleFailedPayment(paymentId, action) {
    return await api.patch(`/payments/${paymentId}/failed`, { action });
  }

  // PAY-06: Financial reconciliation (Admin)
  async reconcileTransactions(reconciliationData) {
    return await api.post('/payments/reconcile', reconciliationData);
  }

  async getReconciliationReport(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/payments/reconciliation?${params}`);
  }
}

export default new PaymentService();

