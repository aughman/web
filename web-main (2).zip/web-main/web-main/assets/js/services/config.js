import api from './api.js';

class ConfigService {
  // CFG-01: Manage product categories
  async getCategories() {
    return await api.get('/config/categories');
  }

  async createCategory(categoryData) {
    return await api.post('/config/categories', categoryData);
  }

  async updateCategory(categoryId, categoryData) {
    return await api.put(`/config/categories/${categoryId}`, categoryData);
  }

  async deleteCategory(categoryId) {
    return await api.delete(`/config/categories/${categoryId}`);
  }

  // CFG-02: Manage attributes (size, color, etc.)
  async getAttributes() {
    return await api.get('/config/attributes');
  }

  async createAttribute(attributeData) {
    return await api.post('/config/attributes', attributeData);
  }

  async updateAttribute(attributeId, attributeData) {
    return await api.put(`/config/attributes/${attributeId}`, attributeData);
  }

  async deleteAttribute(attributeId) {
    return await api.delete(`/config/attributes/${attributeId}`);
  }

  // CFG-03: Shipping fee rules
  async getShippingRules() {
    return await api.get('/config/shipping-rules');
  }

  async createShippingRule(ruleData) {
    return await api.post('/config/shipping-rules', ruleData);
  }

  async updateShippingRule(ruleId, ruleData) {
    return await api.put(`/config/shipping-rules/${ruleId}`, ruleData);
  }

  // CFG-04: Tax / fee configuration
  async getTaxConfig() {
    return await api.get('/config/tax');
  }

  async updateTaxConfig(taxData) {
    return await api.put('/config/tax', taxData);
  }

  // CFG-05: Global system settings
  async getSettings() {
    return await api.get('/config/settings');
  }

  async updateSettings(settingsData) {
    return await api.put('/config/settings', settingsData);
  }
}

export default new ConfigService();

