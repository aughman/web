import api from './api.js';

class ReviewService {
  // REV-01: Submit product review (Customer)
  async submitReview(productId, reviewData) {
    return await api.post(`/reviews/products/${productId}`, reviewData);
  }

  // REV-02: Rating calculation & display
  async getProductRating(productId) {
    return await api.get(`/reviews/products/${productId}/rating`);
  }

  async getProductReviews(productId, filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/reviews/products/${productId}?${params}`);
  }

  // REV-03: Review moderation (Admin)
  async getPendingReviews() {
    return await api.get('/reviews/pending');
  }

  async moderateReview(reviewId, action, reason) {
    return await api.patch(`/reviews/${reviewId}/moderate`, { action, reason });
  }

  // REV-04: Shop response to reviews
  async respondToReview(reviewId, response) {
    return await api.post(`/reviews/${reviewId}/response`, { response });
  }

  async updateReviewResponse(reviewId, response) {
    return await api.put(`/reviews/${reviewId}/response`, { response });
  }

  // REV-05: Review reporting & analytics
  async getReviewAnalytics(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/reviews/analytics?${params}`);
  }

  async getReviewReport(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/reviews/reports?${params}`);
  }
}

export default new ReviewService();

