import api from './api.js';

class ShippingService {
  // SHIP-01: Shipping method configuration
  async getShippingMethods() {
    return await api.get('/shipping/methods');
  }

  async createShippingMethod(methodData) {
    return await api.post('/shipping/methods', methodData);
  }

  async updateShippingMethod(methodId, methodData) {
    return await api.put(`/shipping/methods/${methodId}`, methodData);
  }

  // SHIP-02: Assign shipping to orders
  async assignShipping(orderId, shippingData) {
    return await api.post(`/shipping/orders/${orderId}/assign`, shippingData);
  }

  // SHIP-03: Update delivery status
  async updateDeliveryStatus(orderId, status, location) {
    return await api.patch(`/shipping/orders/${orderId}/status`, { status, location });
  }

  // SHIP-04: Customer delivery tracking
  async trackDelivery(orderId) {
    return await api.get(`/shipping/orders/${orderId}/track`);
  }

  // SHIP-05: Delivery completion confirmation
  async confirmDelivery(orderId, confirmationData) {
    return await api.post(`/shipping/orders/${orderId}/confirm`, confirmationData);
  }
}

export default new ShippingService();

