import api from './api.js';

class ACLService {
  // ACL-01: Define permission matrix
  async getPermissions() {
    return await api.get('/acl/permissions');
  }

  async createPermission(permissionData) {
    return await api.post('/acl/permissions', permissionData);
  }

  async getPermissionMatrix() {
    return await api.get('/acl/matrix');
  }

  // ACL-02: Assign roles to Admin staff
  async assignRole(userId, roleId) {
    return await api.post(`/acl/users/${userId}/roles`, { roleId });
  }

  async removeRole(userId, roleId) {
    return await api.delete(`/acl/users/${userId}/roles/${roleId}`);
  }

  async getUserRoles(userId) {
    return await api.get(`/acl/users/${userId}/roles`);
  }

  // ACL-03: Restrict page access by permission
  async checkPageAccess(page) {
    return await api.get(`/acl/pages/${page}/access`);
  }

  // ACL-04: Audit permission changes
  async getPermissionAuditLogs(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/acl/audit?${params}`);
  }

  // ACL-05: Role-based UI rendering
  async getUIPermissions() {
    return await api.get('/acl/ui-permissions');
  }
}

export default new ACLService();

