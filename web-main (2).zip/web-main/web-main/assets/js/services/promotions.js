import api from './api.js';

class PromotionService {
  // PROMO-01: Create promotion/discount (Admin, Shop)
  async createPromotion(promotionData) {
    return await api.post('/promotions', promotionData);
  }

  // PROMO-02: Edit/delete promotion
  async updatePromotion(promotionId, promotionData) {
    return await api.put(`/promotions/${promotionId}`, promotionData);
  }

  async deletePromotion(promotionId) {
    return await api.delete(`/promotions/${promotionId}`);
  }

  // PROMO-03: Apply discount at checkout
  async validatePromoCode(code) {
    return await api.post('/promotions/validate', { code });
  }

  async applyPromotion(orderId, promoCode) {
    return await api.post(`/promotions/orders/${orderId}/apply`, { code: promoCode });
  }

  // PROMO-04: Promotion validity & rule engine
  async getActivePromotions(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/promotions/active?${params}`);
  }

  // PROMO-05: Promotion performance tracking
  async getPromotionAnalytics(promotionId) {
    return await api.get(`/promotions/${promotionId}/analytics`);
  }

  async getPromotionPerformance(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/promotions/performance?${params}`);
  }
}

export default new PromotionService();

