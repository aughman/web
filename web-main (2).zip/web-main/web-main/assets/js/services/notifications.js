import api from './api.js';

class NotificationService {
  // NOTI-01: Order status notifications
  async sendOrderNotification(orderId, type) {
    return await api.post(`/notifications/orders/${orderId}`, { type });
  }

  // NOTI-02: Payment confirmation notifications
  async sendPaymentNotification(paymentId) {
    return await api.post(`/notifications/payments/${paymentId}`);
  }

  // NOTI-03: Promotion announcements
  async sendPromotionAnnouncement(promotionId, targetAudience) {
    return await api.post(`/notifications/promotions/${promotionId}`, { targetAudience });
  }

  // NOTI-04: System alerts to Admin
  async sendSystemAlert(alertData) {
    return await api.post('/notifications/system/alerts', alertData);
  }

  // NOTI-05: Email & in-app notification system
  async getUserNotifications(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/notifications?${params}`);
  }

  async markAsRead(notificationId) {
    return await api.patch(`/notifications/${notificationId}/read`);
  }

  async markAllAsRead() {
    return await api.patch('/notifications/read-all');
  }

  async getUnreadCount() {
    return await api.get('/notifications/unread-count');
  }
}

export default new NotificationService();

