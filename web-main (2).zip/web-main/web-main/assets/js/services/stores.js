import api from './api.js';

class StoreService {
  // STORE-01: Create shop profile (Admin)
  async createShop(shopData) {
    return await api.post('/stores', shopData);
  }

  // STORE-02: Edit shop information (Admin)
  async updateShop(shopId, shopData) {
    return await api.put(`/stores/${shopId}`, shopData);
  }

  // STORE-03: Activate / deactivate shop
  async activateShop(shopId) {
    return await api.patch(`/stores/${shopId}/activate`);
  }

  async deactivateShop(shopId, reason) {
    return await api.patch(`/stores/${shopId}/deactivate`, { reason });
  }

  // STORE-04: View shop performance summary
  async getShopPerformance(shopId, filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/stores/${shopId}/performance?${params}`);
  }

  // STORE-05: Shop self-profile management
  async getShopProfile() {
    return await api.get('/stores/profile');
  }

  async updateShopProfile(profileData) {
    return await api.put('/stores/profile', profileData);
  }

  // STORE-06: Shop verification / approval workflow
  async requestVerification(shopId, verificationData) {
    return await api.post(`/stores/${shopId}/verification`, verificationData);
  }

  async approveShop(shopId) {
    return await api.patch(`/stores/${shopId}/approve`);
  }

  async rejectShop(shopId, reason) {
    return await api.patch(`/stores/${shopId}/reject`, { reason });
  }

  async getPendingShops() {
    return await api.get('/stores/pending');
  }
}

export default new StoreService();

