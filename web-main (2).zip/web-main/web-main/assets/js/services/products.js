import api from './api.js';

class ProductService {
  // PROD-01: Create product (Shop)
  async createProduct(productData) {
    return await api.post('/products', productData);
  }

  // PROD-02: Edit product details (Shop)
  async updateProduct(productId, productData) {
    return await api.put(`/products/${productId}`, productData);
  }

  // PROD-03: Delete/disable product (Shop)
  async deleteProduct(productId) {
    return await api.delete(`/products/${productId}`);
  }

  async disableProduct(productId) {
    return await api.patch(`/products/${productId}/disable`);
  }

  // PROD-04: Product approval workflow (Admin)
  async approveProduct(productId) {
    return await api.patch(`/products/${productId}/approve`);
  }

  async rejectProduct(productId, reason) {
    return await api.patch(`/products/${productId}/reject`, { reason });
  }

  async getPendingProducts() {
    return await api.get('/products/pending');
  }

  // PROD-05: Product categorization & attributes
  async getCategories() {
    return await api.get('/products/categories');
  }

  async getAttributes() {
    return await api.get('/products/attributes');
  }

  // PROD-06: Product image upload & management
  async uploadProductImage(productId, imageFile) {
    const formData = new FormData();
    formData.append('image', imageFile);
    return await api.upload(`/products/${productId}/images`, formData);
  }

  async deleteProductImage(productId, imageId) {
    return await api.delete(`/products/${productId}/images/${imageId}`);
  }

  // PROD-07: Product search & filtering (Customer)
  async searchProducts(query, filters = {}) {
    const params = new URLSearchParams({ q: query, ...filters });
    return await api.get(`/products/search?${params}`);
  }

  async getProducts(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/products?${params}`);
  }

  // PROD-08: Product detail page (Customer)
  async getProduct(productId) {
    return await api.get(`/products/${productId}`);
  }

  async getRelatedProducts(productId) {
    return await api.get(`/products/${productId}/related`);
  }
}

export default new ProductService();

