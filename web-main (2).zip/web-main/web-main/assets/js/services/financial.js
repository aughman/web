import api from './api.js';

class FinancialService {
  // FIN-01: Revenue tracking per shop
  async getShopRevenue(shopId, filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/financial/shops/${shopId}/revenue?${params}`);
  }

  // FIN-02: Expense management
  async createExpense(expenseData) {
    return await api.post('/financial/expenses', expenseData);
  }

  async getExpenses(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/financial/expenses?${params}`);
  }

  async updateExpense(expenseId, expenseData) {
    return await api.put(`/financial/expenses/${expenseId}`, expenseData);
  }

  // FIN-03: Profit/loss calculation
  async getProfitLoss(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/financial/profit-loss?${params}`);
  }

  // FIN-04: Financial summary for Admin
  async getFinancialSummary(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/financial/summary?${params}`);
  }

  // FIN-05: Financial audit logs
  async getAuditLogs(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/financial/audit-logs?${params}`);
  }
}

export default new FinancialService();

