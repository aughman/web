import api from './api.js';
import { STORAGE_KEYS, APP_CONFIG } from '../config.js';

class AuthService {
  // AUTH-01: User registration (Customer, Shop)
  async register(userData) {
    const response = await api.post('/auth/register', userData);
    if (response.token) {
      this.setAuthToken(response.token);
      this.setUserData(response.user);
    }
    return response;
  }

  // AUTH-02: User login/logout
  async login(email, password, role, rememberMe = false) {
    const response = await api.post('/auth/login', { email, password, role });
    if (response.token) {
      this.setAuthToken(response.token, rememberMe);
      this.setUserData(response.user);
    }
    return response;
  }

  async logout() {
    try {
      await api.post('/auth/logout');
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      this.clearAuth();
    }
  }

  // AUTH-03: Password reset & email verification
  async requestPasswordReset(email) {
    return await api.post('/auth/password-reset/request', { email });
  }

  async resetPassword(token, newPassword) {
    return await api.post('/auth/password-reset/confirm', { token, newPassword });
  }

  async verifyEmail(token) {
    return await api.post('/auth/verify-email', { token });
  }

  // AUTH-04: Role-based access control
  hasRole(requiredRole) {
    const user = this.getUserData();
    return user?.role === requiredRole;
  }

  hasAnyRole(roles) {
    const user = this.getUserData();
    return roles.includes(user?.role);
  }

  // AUTH-05: Permission management for internal staff
  hasPermission(permission) {
    const user = this.getUserData();
    return user?.permissions?.includes(permission) || false;
  }

  // AUTH-06: Session management & security validation
  isAuthenticated() {
    return !!this.getAuthToken();
  }

  getAuthToken() {
    return localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) || 
           sessionStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
  }

  setAuthToken(token, rememberMe = false) {
    if (rememberMe) {
      localStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token);
      localStorage.setItem(STORAGE_KEYS.REMEMBER_ME, 'true');
    } else {
      sessionStorage.setItem(STORAGE_KEYS.AUTH_TOKEN, token);
    }
  }

  getUserData() {
    const data = localStorage.getItem(STORAGE_KEYS.USER_DATA) || 
                 sessionStorage.getItem(STORAGE_KEYS.USER_DATA);
    return data ? JSON.parse(data) : null;
  }

  setUserData(user) {
    const data = JSON.stringify(user);
    const rememberMe = localStorage.getItem(STORAGE_KEYS.REMEMBER_ME) === 'true';
    if (rememberMe) {
      localStorage.setItem(STORAGE_KEYS.USER_DATA, data);
    } else {
      sessionStorage.setItem(STORAGE_KEYS.USER_DATA, data);
    }
  }

  clearAuth() {
    localStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.USER_DATA);
    localStorage.removeItem(STORAGE_KEYS.REMEMBER_ME);
    sessionStorage.removeItem(STORAGE_KEYS.AUTH_TOKEN);
    sessionStorage.removeItem(STORAGE_KEYS.USER_DATA);
  }

  // Validate token and refresh if needed
  async validateSession() {
    if (!this.isAuthenticated()) return false;
    
    try {
      const response = await api.get('/auth/validate');
      if (response.user) {
        this.setUserData(response.user);
      }
      return true;
    } catch (error) {
      this.clearAuth();
      return false;
    }
  }
}

export default new AuthService();

