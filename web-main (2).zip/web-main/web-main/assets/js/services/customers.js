import api from './api.js';

class CustomerService {
  // CUST-01: Customer profile management
  async getProfile() {
    return await api.get('/customers/profile');
  }

  async updateProfile(profileData) {
    return await api.put('/customers/profile', profileData);
  }

  // CUST-02: Admin view/edit customer information
  async getAllCustomers(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/customers/admin?${params}`);
  }

  async getCustomer(customerId) {
    return await api.get(`/customers/${customerId}`);
  }

  async updateCustomer(customerId, customerData) {
    return await api.put(`/customers/${customerId}`, customerData);
  }

  // CUST-03: Customer order history
  async getCustomerOrderHistory(customerId) {
    return await api.get(`/customers/${customerId}/orders`);
  }

  // CUST-04: Account status management (active/blocked)
  async updateAccountStatus(customerId, status, reason) {
    return await api.patch(`/customers/${customerId}/status`, { status, reason });
  }
}

export default new CustomerService();

