import api from './api.js';

class OrderService {
  // ORD-01: Create order (Customer)
  async createOrder(orderData) {
    return await api.post('/orders', orderData);
  }

  // ORD-02: View order history (Customer)
  async getCustomerOrders(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/orders/customer?${params}`);
  }

  // ORD-03: Order status tracking (Customer)
  async getOrderStatus(orderId) {
    return await api.get(`/orders/${orderId}/status`);
  }

  async trackOrder(orderId) {
    return await api.get(`/orders/${orderId}/track`);
  }

  // ORD-04: View & process orders (Shop)
  async getShopOrders(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/orders/shop?${params}`);
  }

  async processOrder(orderId, action) {
    return await api.patch(`/orders/${orderId}/process`, { action });
  }

  // ORD-05: Update order status (confirmed, shipped, completed)
  async updateOrderStatus(orderId, status, notes) {
    return await api.patch(`/orders/${orderId}/status`, { status, notes });
  }

  // ORD-06: Admin order overview & intervention
  async getAllOrders(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/orders/admin?${params}`);
  }

  async interveneOrder(orderId, action, reason) {
    return await api.patch(`/orders/${orderId}/intervene`, { action, reason });
  }

  // ORD-07: Order cancellation & refund handling
  async cancelOrder(orderId, reason) {
    return await api.patch(`/orders/${orderId}/cancel`, { reason });
  }

  async requestRefund(orderId, reason) {
    return await api.post(`/orders/${orderId}/refund`, { reason });
  }

  async processRefund(orderId, amount, reason) {
    return await api.patch(`/orders/${orderId}/refund/process`, { amount, reason });
  }
}

export default new OrderService();

