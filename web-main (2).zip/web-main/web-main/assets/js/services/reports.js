import api from './api.js';

class ReportService {
  // RPT-01: Sales reports (Shop)
  async getSalesReport(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/reports/sales?${params}`);
  }

  // RPT-02: Order & customer reports
  async getOrderReport(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/reports/orders?${params}`);
  }

  async getCustomerReport(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/reports/customers?${params}`);
  }

  // RPT-03: System activity reports (Admin)
  async getActivityReport(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/reports/activity?${params}`);
  }

  // RPT-04: Export reports (CSV/PDF)
  async exportReport(reportType, format, filters = {}) {
    const params = new URLSearchParams({ format, ...filters });
    return await api.get(`/reports/${reportType}/export?${params}`, {
      responseType: 'blob',
    });
  }

  // RPT-05: Dashboard overview (Admin)
  async getDashboardData(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/reports/dashboard?${params}`);
  }
}

export default new ReportService();

