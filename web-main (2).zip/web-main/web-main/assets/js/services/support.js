import api from './api.js';

class SupportService {
  // SUP-01: Customer support ticket creation
  async createTicket(ticketData) {
    return await api.post('/support/tickets', ticketData);
  }

  // SUP-02: Shop support ticket handling
  async getShopTickets(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/support/tickets/shop?${params}`);
  }

  async respondToTicket(ticketId, response) {
    return await api.post(`/support/tickets/${ticketId}/respond`, { response });
  }

  // SUP-03: Admin support management
  async getAllTickets(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/support/tickets/admin?${params}`);
  }

  async assignTicket(ticketId, assigneeId) {
    return await api.patch(`/support/tickets/${ticketId}/assign`, { assigneeId });
  }

  async escalateTicket(ticketId, reason) {
    return await api.patch(`/support/tickets/${ticketId}/escalate`, { reason });
  }

  // SUP-04: Ticket status workflow
  async updateTicketStatus(ticketId, status, notes) {
    return await api.patch(`/support/tickets/${ticketId}/status`, { status, notes });
  }

  async getTicket(ticketId) {
    return await api.get(`/support/tickets/${ticketId}`);
  }

  // SUP-05: Support history & reporting
  async getSupportHistory(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/support/history?${params}`);
  }

  async getSupportReport(filters = {}) {
    const params = new URLSearchParams(filters);
    return await api.get(`/support/reports?${params}`);
  }
}

export default new SupportService();

