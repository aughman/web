import authService from '../services/auth.js';
import productService from '../services/products.js';
import orderService from '../services/orders.js';
import storeService from '../services/stores.js';
import customerService from '../services/customers.js';
import financialService from '../services/financial.js';
import reportService from '../services/reports.js';
import configService from '../services/config.js';
import { showNotification, showLoading, hideLoading, confirmDialog } from '../utils/helpers.js';
import { formatStatus, formatDate } from '../utils/formatters.js';

// Check authentication
if (!authService.isAuthenticated() || !authService.hasRole('admin')) {
  window.location.href = '/signin.html';
}

// Navigation
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const target = link.getAttribute('href').substring(1);
    showSection(target);
  });
});

function showSection(sectionId) {
  document.querySelectorAll('.dashboard-section').forEach(section => {
    section.classList.remove('active');
  });
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.remove('active');
  });
  document.getElementById(sectionId).classList.add('active');
  document.querySelector(`[href="#${sectionId}"]`).classList.add('active');
  
  // Load section data
  if (sectionId === 'overview') loadOverview();
  if (sectionId === 'products') loadProducts();
  if (sectionId === 'orders') loadOrders();
  if (sectionId === 'shops') loadShops();
  if (sectionId === 'customers') loadCustomers();
  if (sectionId === 'financial') loadFinancial();
  if (sectionId === 'reports') setupReports();
  if (sectionId === 'config') setupConfig();
}

// Logout
document.getElementById('logoutBtn').addEventListener('click', async () => {
  await authService.logout();
  window.location.href = '/signin.html';
});

// Load overview
async function loadOverview() {
  try {
    const dashboard = await reportService.getDashboardData();
    document.getElementById('totalRevenue').textContent = `$${dashboard.totalRevenue || 0}`;
    document.getElementById('totalOrders').textContent = dashboard.totalOrders || 0;
    document.getElementById('activeShops').textContent = dashboard.activeShops || 0;
    document.getElementById('totalCustomers').textContent = dashboard.totalCustomers || 0;
    
    // Load recent activity
    const activity = await reportService.getActivityReport({ limit: 10 });
    const container = document.getElementById('recentActivityList');
    container.innerHTML = activity.map(item => `
      <div class="activity-item">
        <div>
          <strong>${item.action}</strong>
          <p>${item.description}</p>
        </div>
        <span>${formatDate(item.createdAt)}</span>
      </div>
    `).join('');
  } catch (error) {
    showNotification(error.message || 'Failed to load overview', 'error');
  }
}

// Load products
async function loadProducts(filterStatus = '') {
  const container = document.getElementById('productsList');
  const spinner = showLoading(container);
  
  try {
    let products;
    if (filterStatus === 'pending') {
      products = await productService.getPendingProducts();
    } else {
      const filters = filterStatus ? { status: filterStatus } : {};
      products = await productService.getProducts(filters);
    }
    
    hideLoading(spinner);
    
    if (!products.length) {
      container.innerHTML = '<p>No products found.</p>';
      return;
    }
    
    container.innerHTML = products.map(product => `
      <div class="dashboard-card">
        <h3>${product.name || 'Unnamed Product'}</h3>
        <p><strong>Shop:</strong> ${product.shopId?.name || 'N/A'}</p>
        <p><strong>Status:</strong> ${formatStatus(product.status || 'pending')}</p>
        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
          ${product.status === 'pending' ? `
            <button class="pill-btn primary" onclick="approveProduct('${product._id || product.id}')">Approve</button>
            <button class="pill-btn tertiary" onclick="rejectProduct('${product._id || product.id}')">Reject</button>
          ` : `
            <button class="pill-btn secondary" onclick="viewProduct('${product._id || product.id}')">View</button>
          `}
        </div>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    console.error('Load products error:', error);
    showNotification(error.message || 'Failed to load products', 'error');
  }
}

window.approveProduct = async (productId) => {
  try {
    await productService.approveProduct(productId);
    showNotification('Product approved', 'success');
    const filterValue = document.getElementById('approvalFilter')?.value || '';
    loadProducts(filterValue);
  } catch (error) {
    showNotification(error.message || 'Failed to approve product', 'error');
  }
};

window.rejectProduct = async (productId) => {
  const reason = prompt('Enter rejection reason:');
  if (!reason) return;
  
  try {
    await productService.rejectProduct(productId, reason);
    showNotification('Product rejected', 'success');
    const filterValue = document.getElementById('approvalFilter')?.value || '';
    loadProducts(filterValue);
  } catch (error) {
    showNotification(error.message || 'Failed to reject product', 'error');
  }
};

// Load orders
async function loadOrders() {
  const container = document.getElementById('ordersList');
  const spinner = showLoading(container);
  
  try {
    const orders = await orderService.getAllOrders();
    hideLoading(spinner);
    
    if (!orders.length) {
      container.innerHTML = '<p>No orders found.</p>';
      return;
    }
    
    container.innerHTML = orders.map(order => `
      <div class="dashboard-card">
        <h3>Order #${order.id}</h3>
        <p><strong>Customer:</strong> ${order.customerName}</p>
        <p><strong>Status:</strong> ${order.status}</p>
        <p><strong>Total:</strong> $${order.total}</p>
        <button class="pill-btn secondary" onclick="viewOrder('${order.id}')">View</button>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    showNotification(error.message || 'Failed to load orders', 'error');
  }
};

// Load shops
async function loadShops() {
  const container = document.getElementById('shopsList');
  const spinner = showLoading(container);
  
  try {
    const shops = await storeService.getPendingShops();
    hideLoading(spinner);
    
    if (!shops.length) {
      container.innerHTML = '<p>No shops found.</p>';
      return;
    }
    
    container.innerHTML = shops.map(shop => `
      <div class="dashboard-card">
        <h3>${shop.name}</h3>
        <p><strong>Status:</strong> ${formatStatus(shop.status)}</p>
        <p><strong>Email:</strong> ${shop.email}</p>
        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
          <button class="pill-btn primary" onclick="approveShop('${shop.id}')">Approve</button>
          <button class="pill-btn tertiary" onclick="rejectShop('${shop.id}')">Reject</button>
        </div>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    showNotification(error.message || 'Failed to load shops', 'error');
  }
}

window.approveShop = async (shopId) => {
  try {
    await storeService.approveShop(shopId);
    showNotification('Shop approved', 'success');
    loadShops();
  } catch (error) {
    showNotification(error.message || 'Failed to approve shop', 'error');
  }
};

window.rejectShop = async (shopId) => {
  const reason = prompt('Enter rejection reason:');
  if (!reason) return;
  
  try {
    await storeService.rejectShop(shopId, reason);
    showNotification('Shop rejected', 'success');
    loadShops();
  } catch (error) {
    showNotification(error.message || 'Failed to reject shop', 'error');
  }
};

// Load customers
async function loadCustomers() {
  const container = document.getElementById('customersList');
  const spinner = showLoading(container);
  
  try {
    const customers = await customerService.getAllCustomers();
    hideLoading(spinner);
    
    if (!customers.length) {
      container.innerHTML = '<p>No customers found.</p>';
      return;
    }
    
    container.innerHTML = customers.map(customer => `
      <div class="dashboard-card">
        <h3>${customer.name}</h3>
        <p><strong>Email:</strong> ${customer.email}</p>
        <p><strong>Status:</strong> ${formatStatus(customer.status)}</p>
        <button class="pill-btn secondary" onclick="viewCustomer('${customer.id}')">View</button>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    showNotification(error.message || 'Failed to load customers', 'error');
  }
}

// Load financial
async function loadFinancial() {
  try {
    const summary = await financialService.getFinancialSummary();
    document.getElementById('revenue').textContent = `$${summary.revenue || 0}`;
    document.getElementById('expenses').textContent = `$${summary.expenses || 0}`;
    document.getElementById('profit').textContent = `$${summary.profit || 0}`;
  } catch (error) {
    showNotification(error.message || 'Failed to load financial data', 'error');
  }
}

// Setup reports
function setupReports() {
  document.querySelectorAll('.report-card').forEach(card => {
    card.addEventListener('click', async () => {
      const reportType = card.dataset.report;
      try {
        const blob = await reportService.exportReport(reportType, 'csv');
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${reportType}-report.csv`;
        a.click();
        showNotification('Report exported successfully', 'success');
      } catch (error) {
        showNotification(error.message || 'Failed to export report', 'error');
      }
    });
  });
}

// Setup config
function setupConfig() {
  document.querySelectorAll('.config-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.config-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      loadConfigTab(tab.dataset.tab);
    });
  });
  
  loadConfigTab('categories');
}

async function loadConfigTab(tab) {
  const container = document.getElementById('configContent');
  const spinner = showLoading(container);
  
  try {
    let data, html = '';
    
    switch (tab) {
      case 'categories':
        data = await configService.getCategories();
        html = data.map(cat => `
          <div class="dashboard-card">
            <h3>${cat.name}</h3>
            <p>${cat.description || ''}</p>
            <button class="pill-btn secondary" onclick="editCategory('${cat.id}')">Edit</button>
          </div>
        `).join('');
        break;
      case 'attributes':
        data = await configService.getAttributes();
        html = data.map(attr => `
          <div class="dashboard-card">
            <h3>${attr.name}</h3>
            <p>Type: ${attr.type}</p>
            <button class="pill-btn secondary" onclick="editAttribute('${attr.id}')">Edit</button>
          </div>
        `).join('');
        break;
      // Add more cases for other config tabs
    }
    
    hideLoading(spinner);
    container.innerHTML = html || '<p>No items found.</p>';
  } catch (error) {
    hideLoading(spinner);
    showNotification(error.message || 'Failed to load config', 'error');
  }
}

// Debounce helper
function debounce(func, wait) {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadOverview();
  
  // Setup product filter
  const approvalFilter = document.getElementById('approvalFilter');
  if (approvalFilter) {
    approvalFilter.addEventListener('change', (e) => {
      loadProducts(e.target.value);
    });
  }
  
  // Setup product search
  const productSearch = document.getElementById('productSearch');
  if (productSearch) {
    productSearch.addEventListener('input', debounce((e) => {
      // Search functionality can be added here
      const filterValue = approvalFilter?.value || '';
      loadProducts(filterValue);
    }, 300));
  }
});

