import authService from '../services/auth.js';
import productService from '../services/products.js';
import orderService from '../services/orders.js';
import inventoryService from '../services/inventory.js';
import storeService from '../services/stores.js';
import reportService from '../services/reports.js';
import { showNotification, showLoading, hideLoading, confirmDialog } from '../utils/helpers.js';
import { formatStatus, formatDate } from '../utils/formatters.js';

// Check authentication
if (!authService.isAuthenticated() || !authService.hasRole('shop')) {
  window.location.href = '/signin.html';
}

// Navigation
document.querySelectorAll('.nav-link').forEach(link => {
  link.addEventListener('click', (e) => {
    e.preventDefault();
    const target = link.getAttribute('href').substring(1);
    showSection(target);
  });
});

function showSection(sectionId) {
  document.querySelectorAll('.dashboard-section').forEach(section => {
    section.classList.remove('active');
  });
  document.querySelectorAll('.nav-link').forEach(link => {
    link.classList.remove('active');
  });
  document.getElementById(sectionId).classList.add('active');
  document.querySelector(`[href="#${sectionId}"]`).classList.add('active');
  
  // Load section data
  if (sectionId === 'products') loadProducts();
  if (sectionId === 'orders') loadOrders();
  if (sectionId === 'inventory') loadInventory();
  if (sectionId === 'analytics') loadAnalytics();
  if (sectionId === 'profile') loadProfile();
}

// Logout
document.getElementById('logoutBtn').addEventListener('click', async () => {
  await authService.logout();
  window.location.href = '/signin.html';
});

// Load products
async function loadProducts() {
  const container = document.getElementById('productsList');
  const spinner = showLoading(container);
  
  try {
    const products = await productService.getProducts();
    hideLoading(spinner);
    
    if (!products.length) {
      container.innerHTML = '<p>No products found. Create your first product!</p>';
      return;
    }
    
    container.innerHTML = products.map(product => `
      <div class="dashboard-card">
        <img src="${product.images?.[0] || '/placeholder.jpg'}" alt="${product.name}" style="width: 100%; height: 200px; object-fit: cover; border-radius: 8px; margin-bottom: 1rem;" />
        <h3>${product.name}</h3>
        <p><strong>Status:</strong> ${formatStatus(product.status)}</p>
        <p><strong>Price:</strong> $${product.price}</p>
        <div style="display: flex; gap: 0.5rem; margin-top: 1rem;">
          <button class="pill-btn secondary" onclick="editProduct('${product.id}')">Edit</button>
          <button class="pill-btn tertiary" onclick="deleteProduct('${product.id}')">Delete</button>
        </div>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    showNotification(error.message || 'Failed to load products', 'error');
  }
}

// Create product modal - initialize after DOM loads
let createProductModal, createProductBtn, closeProductModal, cancelProductBtn, createProductForm;

function initProductModal() {
  createProductModal = document.getElementById('createProductModal');
  createProductBtn = document.getElementById('createProductBtn');
  closeProductModal = document.getElementById('closeProductModal');
  cancelProductBtn = document.getElementById('cancelProductBtn');
  createProductForm = document.getElementById('createProductForm');

  if (!createProductModal || !createProductBtn || !createProductForm) {
    console.error('Product modal elements not found');
    return;
  }

  function openProductModal() {
    createProductModal.style.display = 'flex';
    document.body.style.overflow = 'hidden';
  }

  function closeProductModalFunc() {
    createProductModal.style.display = 'none';
    document.body.style.overflow = '';
    if (createProductForm) createProductForm.reset();
  }

  createProductBtn.addEventListener('click', openProductModal);
  if (closeProductModal) closeProductModal.addEventListener('click', closeProductModalFunc);
  if (cancelProductBtn) cancelProductBtn.addEventListener('click', closeProductModalFunc);

  // Close modal when clicking outside
  createProductModal.addEventListener('click', (e) => {
    if (e.target === createProductModal) {
      closeProductModalFunc();
    }
  });

  // Handle product creation form submission
  createProductForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const submitButton = createProductForm.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.disabled = true;
    submitButton.textContent = 'Creating...';

    try {
      const productData = {
        name: document.getElementById('productName').value,
        description: document.getElementById('productDescription').value,
        price: parseFloat(document.getElementById('productPrice').value),
        collectionId: document.getElementById('productCollection').value,
        stock: {
          quantity: parseInt(document.getElementById('productStock').value) || 0,
          lowStockThreshold: 10
        },
        category: null, // Optional - backend will handle
        images: document.getElementById('productImageUrl').value ? [document.getElementById('productImageUrl').value] : [],
        tags: document.getElementById('productTags').value 
          ? document.getElementById('productTags').value.split(',').map(t => t.trim()).filter(t => t)
          : []
      };

      await productService.createProduct(productData);
      showNotification('Product created successfully! It will be reviewed by admin.', 'success');
      closeProductModalFunc();
      loadProducts(); // Refresh the product list
    } catch (error) {
      console.error('Create product error:', error);
      showNotification(error.message || 'Failed to create product', 'error');
    } finally {
      submitButton.disabled = false;
      submitButton.textContent = originalText;
    }
  });
}

// Edit product
window.editProduct = (productId) => {
  window.location.href = `/products/${productId}/edit.html`;
};

// Delete product
window.deleteProduct = async (productId) => {
  const confirmed = await confirmDialog('Are you sure you want to delete this product?');
  if (!confirmed) return;
  
  try {
    await productService.deleteProduct(productId);
    showNotification('Product deleted successfully', 'success');
    loadProducts();
  } catch (error) {
    showNotification(error.message || 'Failed to delete product', 'error');
  }
};

// Load orders
async function loadOrders() {
  const container = document.getElementById('ordersList');
  const spinner = showLoading(container);
  
  try {
    const orders = await orderService.getShopOrders();
    hideLoading(spinner);
    
    if (!orders.length) {
      container.innerHTML = '<p>No orders found.</p>';
      return;
    }
    
    container.innerHTML = orders.map(order => `
      <div class="dashboard-card">
        <h3>Order #${order.id}</h3>
        <p><strong>Date:</strong> ${formatDate(order.createdAt)}</p>
        <p><strong>Status:</strong> ${order.status}</p>
        <p><strong>Total:</strong> $${order.total}</p>
        <button class="pill-btn primary" onclick="processOrder('${order.id}')">Process</button>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    showNotification(error.message || 'Failed to load orders', 'error');
  }
}

// Process order
window.processOrder = async (orderId) => {
  const action = prompt('Enter action (confirm/ship):');
  if (!action) return;
  
  try {
    await orderService.processOrder(orderId, action);
    showNotification('Order processed successfully', 'success');
    loadOrders();
  } catch (error) {
    showNotification(error.message || 'Failed to process order', 'error');
  }
};

// Load inventory
async function loadInventory() {
  const container = document.getElementById('inventoryList');
  const spinner = showLoading(container);
  
  try {
    // Use shop-specific inventory endpoint
    const inventory = await inventoryService.getShopInventoryReport();
    hideLoading(spinner);
    
    if (!inventory.length) {
      container.innerHTML = '<p>No inventory items found. Create products to manage inventory.</p>';
      return;
    }
    
    container.innerHTML = inventory.map(item => `
      <div class="dashboard-card">
        <h3>${item.productName}</h3>
        <p><strong>Stock:</strong> ${item.quantity}</p>
        <p><strong>Low Stock:</strong> ${item.lowStock ? 'Yes' : 'No'}</p>
        <button class="pill-btn secondary" onclick="adjustInventory('${item.productId}')">Adjust</button>
      </div>
    `).join('');
  } catch (error) {
    hideLoading(spinner);
    console.error('Inventory load error:', error);
    // Show user-friendly error message
    if (error.message && error.message.includes('permissions')) {
      container.innerHTML = '<p style="color: var(--error);">Unable to load inventory. Please ensure your shop account is approved.</p>';
    } else {
      showNotification(error.message || 'Failed to load inventory', 'error');
      container.innerHTML = '<p>Failed to load inventory. Please try again later.</p>';
    }
  }
}

// Adjust inventory
window.adjustInventory = async (productId) => {
  const quantity = prompt('Enter new quantity:');
  if (!quantity) return;
  
  const reason = prompt('Enter reason for adjustment:');
  
  try {
    await inventoryService.adjustInventory(productId, {
      quantity: parseInt(quantity),
      reason: reason || 'Manual adjustment',
    });
    showNotification('Inventory adjusted successfully', 'success');
    loadInventory();
  } catch (error) {
    showNotification(error.message || 'Failed to adjust inventory', 'error');
  }
};

// Load analytics
async function loadAnalytics() {
  try {
    const report = await reportService.getSalesReport();
    document.getElementById('totalSales').textContent = `$${report.totalSales || 0}`;
    document.getElementById('totalOrders').textContent = report.totalOrders || 0;
    
    const products = await productService.getProducts();
    document.getElementById('totalProducts').textContent = products.length || 0;
  } catch (error) {
    showNotification(error.message || 'Failed to load analytics', 'error');
  }
}

// Load profile
async function loadProfile() {
  try {
    const profile = await storeService.getShopProfile();
    document.getElementById('shopName').value = profile.name || '';
    document.getElementById('shopDescription').value = profile.description || '';
    document.getElementById('shopEmail').value = profile.email || '';
  } catch (error) {
    showNotification(error.message || 'Failed to load profile', 'error');
  }
}

// Save profile
document.getElementById('profileForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const profileData = {
    name: document.getElementById('shopName').value,
    description: document.getElementById('shopDescription').value,
    email: document.getElementById('shopEmail').value,
  };
  
  try {
    await storeService.updateShopProfile(profileData);
    showNotification('Profile updated successfully', 'success');
  } catch (error) {
    showNotification(error.message || 'Failed to update profile', 'error');
  }
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  initProductModal();
  loadProducts();
});

