// Enhanced app.js with authentication and routing
import authService from './services/auth.js';
import { showNotification } from './utils/helpers.js';
import { APP_CONFIG } from './config.js';

// Update header based on authentication state
function updateHeaderAuthState() {
  const signInLink = document.getElementById('signInLink');
  const signUpLink = document.getElementById('signUpLink');
  const dashboardLink = document.getElementById('dashboardLink');
  const logoutLink = document.getElementById('logoutLink');
  
  if (signInLink && dashboardLink && logoutLink) {
    const isAuthenticated = authService.isAuthenticated();
    const user = authService.getUserData();
    
    if (isAuthenticated && user) {
      // User is logged in - show Dashboard and Logout
      signInLink.style.display = 'none';
      if (signUpLink) signUpLink.style.display = 'none';
      dashboardLink.style.display = 'inline-block';
      logoutLink.style.display = 'inline-block';
      
      // Set dashboard link based on role
      if (user.role === 'admin') {
        dashboardLink.href = 'dashboard/admin.html';
      } else if (user.role === 'shop') {
        dashboardLink.href = 'dashboard/shop.html';
      } else {
        dashboardLink.href = 'dashboard/customer.html';
      }
      
      // Handle logout
      logoutLink.addEventListener('click', async (e) => {
        e.preventDefault();
        try {
          await authService.logout();
          showNotification('Logged out successfully', 'success');
          setTimeout(() => {
            window.location.reload();
          }, 500);
        } catch (error) {
          console.error('Logout error:', error);
          window.location.reload();
        }
      });
    } else {
      // User is not logged in - show Sign in
      signInLink.style.display = 'inline-block';
      if (signUpLink) signUpLink.style.display = 'none';
      dashboardLink.style.display = 'none';
      logoutLink.style.display = 'none';
    }
  }
}

// Initialize authentication
document.addEventListener('DOMContentLoaded', async () => {
  // Check if user is authenticated
  const isAuthPage = window.location.pathname.includes('signin') || 
                     window.location.pathname.includes('signup');
  
  if (!isAuthPage) {
    const isValid = await authService.validateSession();
    if (!isValid && window.location.pathname !== '/index.html' && 
        window.location.pathname !== '/') {
      window.location.href = '/signin.html';
    }
  }
  
  // Update header authentication state for index page
  if (window.location.pathname === '/index.html' || window.location.pathname === '/') {
    updateHeaderAuthState();
  }

  // Handle sign in form
  const signinForm = document.querySelector('form.auth-form');
  if (signinForm && window.location.pathname.includes('signin')) {
    signinForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submitButton = signinForm.querySelector('button[type="submit"]');
      const originalButtonText = submitButton.textContent;
      
      // Disable button and show loading state
      submitButton.disabled = true;
      submitButton.textContent = 'Signing in...';
      
      const formData = new FormData(signinForm);
      const email = formData.get('email');
      const password = formData.get('password');
      const role = formData.get('role') || 'customer';
      const rememberMe = formData.get('remember') === 'on';

      try {
        // Map "partner" to "shop" for backend compatibility
        const backendRole = role === 'partner' ? 'shop' : role;
        console.log('Attempting login with:', { email, role: backendRole });
        
        const response = await authService.login(email, password, backendRole, rememberMe);
        console.log('Login response:', response);
        
        const user = authService.getUserData();
        console.log('User data:', user);
        
        if (!user) {
          submitButton.disabled = false;
          submitButton.textContent = originalButtonText;
          showNotification('Login failed: No user data received', 'error');
          return;
        }
        
        showNotification('Login successful! Redirecting...', 'success');
        
        // Redirect based on role
        setTimeout(() => {
          if (user.role === APP_CONFIG.roles.ADMIN || user.role === 'admin') {
            window.location.href = '/dashboard/admin.html';
          } else if (user.role === APP_CONFIG.roles.SHOP || user.role === 'shop') {
            window.location.href = '/dashboard/shop.html';
          } else {
            window.location.href = '/dashboard/customer.html';
          }
        }, 500);
      } catch (error) {
        console.error('Login error:', error);
        submitButton.disabled = false;
        submitButton.textContent = originalButtonText;
        showNotification(error.message || 'Login failed. Please check your credentials.', 'error');
      }
    });
  }

  // Handle sign up form
  const signupForm = document.querySelector('form.auth-form');
  if (signupForm && window.location.pathname.includes('signup')) {
    signupForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const formData = new FormData(signupForm);
      const userData = {
        name: formData.get('name'),
        email: formData.get('email'),
        password: formData.get('password'),
        notes: formData.get('notes'),
      };

      try {
        await authService.register(userData);
        showNotification('Account created successfully!', 'success');
        setTimeout(() => {
          window.location.href = '/signin.html';
        }, 1500);
      } catch (error) {
        console.error('Registration error:', error);
        showNotification(error.message || 'Registration failed. Please try again.', 'error');
      }
    });
  }
});

// Export for use in other modules
export { authService };

