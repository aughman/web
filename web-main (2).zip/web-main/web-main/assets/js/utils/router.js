class Router {
  constructor() {
    this.routes = [];
    this.currentRoute = null;
    this.init();
  }

  init() {
    window.addEventListener('popstate', () => this.handleRoute());
    this.handleRoute();
  }

  addRoute(path, handler, requiresAuth = false, requiredRole = null) {
    this.routes.push({ path, handler, requiresAuth, requiredRole });
  }

  navigate(path, replace = false) {
    if (replace) {
      window.history.replaceState({}, '', path);
    } else {
      window.history.pushState({}, '', path);
    }
    this.handleRoute();
  }

  async handleRoute() {
    const path = window.location.pathname;
    const route = this.routes.find(r => {
      const routePath = r.path.replace(/:\w+/g, '([^/]+)');
      const regex = new RegExp(`^${routePath}$`);
      return regex.test(path);
    });

    if (route) {
      if (route.requiresAuth) {
        const authService = (await import('../services/auth.js')).default;
        if (!authService.isAuthenticated()) {
          this.navigate('/signin.html', true);
          return;
        }
        if (route.requiredRole && !authService.hasRole(route.requiredRole)) {
          this.navigate('/unauthorized.html', true);
          return;
        }
      }
      route.handler();
    }
  }

  getParams() {
    const path = window.location.pathname;
    const route = this.routes.find(r => {
      const routePath = r.path.replace(/:\w+/g, '([^/]+)');
      const regex = new RegExp(`^${routePath}$`);
      return regex.test(path);
    });
    
    if (!route) return {};
    
    const paramNames = route.path.match(/:(\w+)/g)?.map(p => p.slice(1)) || [];
    const values = path.match(new RegExp(route.path.replace(/:\w+/g, '([^/]+)')));
    
    if (!values) return {};
    
    const params = {};
    paramNames.forEach((name, index) => {
      params[name] = values[index + 1];
    });
    
    return params;
  }
}

export default new Router();

