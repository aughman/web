import { APP_CONFIG } from '../config.js';

// Format status badge
export function formatStatus(status) {
  const statusMap = {
    'TO DO': { class: 'status-todo', label: 'TO DO' },
    'IN PROGRESS': { class: 'status-in-progress', label: 'IN PROGRESS' },
    'DONE': { class: 'status-done', label: 'DONE' },
    'PENDING': { class: 'status-pending', label: 'PENDING' },
    'APPROVED': { class: 'status-approved', label: 'APPROVED' },
    'REJECTED': { class: 'status-rejected', label: 'REJECTED' },
    'ACTIVE': { class: 'status-active', label: 'ACTIVE' },
    'INACTIVE': { class: 'status-inactive', label: 'INACTIVE' },
    'BLOCKED': { class: 'status-blocked', label: 'BLOCKED' },
  };

  const statusInfo = statusMap[status] || { class: 'status-default', label: status };
  return `<span class="status-badge ${statusInfo.class}">${statusInfo.label}</span>`;
}

// Format role badge
export function formatRole(role) {
  const roleMap = {
    customer: { class: 'role-customer', label: 'Customer' },
    shop: { class: 'role-shop', label: 'Shop' },
    admin: { class: 'role-admin', label: 'Admin' },
  };

  const roleInfo = roleMap[role] || { class: 'role-default', label: role };
  return `<span class="role-badge ${roleInfo.class}">${roleInfo.label}</span>`;
}

// Format order status
export function formatOrderStatus(status) {
  const statusMap = {
    'pending': { class: 'order-pending', label: 'Pending' },
    'confirmed': { class: 'order-confirmed', label: 'Confirmed' },
    'processing': { class: 'order-processing', label: 'Processing' },
    'shipped': { class: 'order-shipped', label: 'Shipped' },
    'delivered': { class: 'order-delivered', label: 'Delivered' },
    'cancelled': { class: 'order-cancelled', label: 'Cancelled' },
    'refunded': { class: 'order-refunded', label: 'Refunded' },
  };

  const statusInfo = statusMap[status] || { class: 'order-default', label: status };
  return `<span class="order-status ${statusInfo.class}">${statusInfo.label}</span>`;
}

// Format payment status
export function formatPaymentStatus(status) {
  const statusMap = {
    'pending': { class: 'payment-pending', label: 'Pending' },
    'processing': { class: 'payment-processing', label: 'Processing' },
    'completed': { class: 'payment-completed', label: 'Completed' },
    'failed': { class: 'payment-failed', label: 'Failed' },
    'refunded': { class: 'payment-refunded', label: 'Refunded' },
  };

  const statusInfo = statusMap[status] || { class: 'payment-default', label: status };
  return `<span class="payment-status ${statusInfo.class}">${statusInfo.label}</span>`;
}

// Format rating stars
export function formatRating(rating, maxRating = 5) {
  const fullStars = Math.floor(rating);
  const hasHalfStar = rating % 1 >= 0.5;
  const emptyStars = maxRating - fullStars - (hasHalfStar ? 1 : 0);

  let html = '';
  for (let i = 0; i < fullStars; i++) {
    html += '<span class="star full">★</span>';
  }
  if (hasHalfStar) {
    html += '<span class="star half">★</span>';
  }
  for (let i = 0; i < emptyStars; i++) {
    html += '<span class="star empty">★</span>';
  }
  return html;
}

// Format date
export function formatDate(date, options = {}) {
  const defaultOptions = {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  };
  if (!date) return 'N/A';
  return new Date(date).toLocaleDateString('en-US', { ...defaultOptions, ...options });
}

// Format date time
export function formatDateTime(date) {
  if (!date) return 'N/A';
  return new Date(date).toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}
