// API Configuration
export const API_CONFIG = {
  baseURL: 'http://localhost:3000/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
};

// Application Configuration
export const APP_CONFIG = {
  name: 'Collab Nexus',
  version: '1.0.0',
  roles: {
    CUSTOMER: 'customer',
    SHOP: 'shop',
    ADMIN: 'admin',
  },
  statuses: {
    TODO: 'TO DO',
    IN_PROGRESS: 'IN PROGRESS',
    DONE: 'DONE',
  },
};

// Storage Keys
export const STORAGE_KEYS = {
  AUTH_TOKEN: 'auth_token',
  USER_DATA: 'user_data',
  REMEMBER_ME: 'remember_me',
};

