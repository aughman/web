# Quick Setup Guide

## 1. Install Dependencies

```bash
cd server
npm install
```

## 2. Create .env File

Create a `.env` file in the `server` directory with this content:

```
MONGODB_URI=mongodb+srv://bunbunlovechocolate_db_user:lXLPtsMIUtBn70vY@nexuscollab.cogm2p3.mongodb.net/nexuscollab?retryWrites=true&w=majority
JWT_SECRET=collab-nexus-super-secret-jwt-key-2025-production
PORT=3000
NODE_ENV=development
FRONTEND_URL=http://localhost:8000
```

## 3. Start the Server

```bash
npm start
```

The server will run on `http://localhost:3000`

## 4. Test the Connection

Visit `http://localhost:3000/api/health` - you should see:
```json
{
  "status": "ok",
  "message": "Collab Nexus API is running"
}
```

## 5. Frontend is Already Configured

The frontend is already set to connect to `http://localhost:3000/api` - no changes needed!

## Next Steps

1. Start the backend: `cd server && npm start`
2. Start the frontend: Serve the `web-main` folder (e.g., `python -m http.server 8000`)
3. Open `http://localhost:8000` in your browser
4. Register a new account and start using the platform!

