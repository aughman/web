import mongoose from 'mongoose';
import User from '../models/User.js';
import Shop from '../models/Shop.js';
import dotenv from 'dotenv';

dotenv.config();

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb+srv://bunbunlovechocolate_db_user:lXLPtsMIUtBn70vY@nexuscollab.cogm2p3.mongodb.net/nexuscollab?retryWrites=true&w=majority';

const shopCredentials = {
  name: 'Team Cherry',
  email: 'teamcherry@collabnexus.com',
  password: 'TeamCherry2025!',
  company: 'Team Cherry'
};

async function createTeamCherryShop() {
  try {
    // Connect to MongoDB
    await mongoose.connect(MONGODB_URI);
    console.log('✅ Connected to MongoDB');

    // Check if user already exists
    const existingUser = await User.findOne({ email: shopCredentials.email });
    if (existingUser) {
      console.log('⚠️  User already exists. Deleting old account...');
      const oldShop = await Shop.findOne({ ownerId: existingUser._id });
      if (oldShop) {
        await Shop.deleteOne({ _id: oldShop._id });
      }
      await User.deleteOne({ _id: existingUser._id });
    }

    // Create user with shop role
    const user = new User({
      name: shopCredentials.name,
      email: shopCredentials.email,
      password: shopCredentials.password,
      role: 'shop',
      company: shopCredentials.company,
      status: 'active'
    });

    await user.save();
    console.log('✅ User created:', user.email);

    // Create shop
    const shop = new Shop({
      name: shopCredentials.company,
      email: shopCredentials.email,
      ownerId: user._id,
      status: 'approved', // Auto-approve for Team Cherry
      verificationStatus: 'verified',
      description: 'Official Team Cherry shop for Hollow Knight and Silksong merchandise'
    });

    await shop.save();
    console.log('✅ Shop created:', shop.name);

    // Link shop to user
    user.shopId = shop._id;
    await user.save();

    console.log('\n🎉 Team Cherry Shop Created Successfully!');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📧 Email:', shopCredentials.email);
    console.log('🔑 Password:', shopCredentials.password);
    console.log('🏪 Shop Name:', shopCredentials.company);
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('\nYou can now login with these credentials!');
    console.log('Role: Partner (Shop)');

    process.exit(0);
  } catch (error) {
    console.error('❌ Error creating shop:', error);
    process.exit(1);
  }
}

createTeamCherryShop();
