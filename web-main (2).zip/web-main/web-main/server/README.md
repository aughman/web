# Collab Nexus Backend Server

Node.js/Express backend server for Collab Nexus e-commerce platform.

## Setup

1. **Install Dependencies**
   ```bash
   cd server
   npm install
   ```

2. **Environment Configuration**
   - The `.env` file is already configured with your MongoDB connection string
   - JWT_SECRET is set (change in production)
   - PORT is set to 3000

3. **Start Server**
   ```bash
   npm start
   ```
   
   For development with auto-reload:
   ```bash
   npm run dev
   ```

## MongoDB Connection

The server is configured to connect to:
- **Database**: `nexuscollab`
- **Cluster**: `NexusCollab`
- **Connection String**: Already configured in `.env`

## API Endpoints

All endpoints are prefixed with `/api`:

- `/api/auth` - Authentication
- `/api/products` - Products
- `/api/orders` - Orders
- `/api/payments` - Payments
- `/api/inventory` - Inventory
- `/api/shipping` - Shipping
- `/api/customers` - Customers
- `/api/reviews` - Reviews
- `/api/promotions` - Promotions
- `/api/notifications` - Notifications
- `/api/reports` - Reports
- `/api/financial` - Financial
- `/api/support` - Support
- `/api/stores` - Stores/Shops
- `/api/acl` - Access Control
- `/api/config` - Configuration

## Health Check

Visit `http://localhost:3000/api/health` to verify the server is running.

## Frontend Integration

Update the frontend config to point to this server:
- File: `assets/js/config.js`
- Set: `baseURL: 'http://localhost:3000/api'`

## Database Models

- **User**: Customers, Shops, Admins
- **Product**: Products with categories, images, stock
- **Order**: Orders with items, status, payments
- **Shop**: Shop profiles and verification

## Authentication

Uses JWT tokens. Tokens are included in the `Authorization` header:
```
Authorization: Bearer <token>
```

## Development Notes

- Some endpoints return placeholder data (payments, notifications, etc.)
- File uploads need multer configuration
- Email functionality needs nodemailer setup
- Payment gateway integration needed for production

