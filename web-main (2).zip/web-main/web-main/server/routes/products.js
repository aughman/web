import express from 'express';
import Product from '../models/Product.js';
import Shop from '../models/Shop.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// PROD-07: Product search & filtering (Customer)
router.get('/', async (req, res, next) => {
  try {
    const { category, status, search, limit = 50, offset = 0 } = req.query;
    const query = {};

    if (category) query.category = category;
    if (status) query.status = status;
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } }
      ];
    }

    const products = await Product.find(query)
      .populate('category', 'name')
      .populate('shopId', 'name')
      .limit(parseInt(limit))
      .skip(parseInt(offset))
      .sort({ createdAt: -1 });

    res.json(products);
  } catch (error) {
    next(error);
  }
});

// PROD-04: Product approval workflow (Admin) - MUST come before /:id route
router.get('/pending', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const products = await Product.find({ status: 'pending' })
      .populate('shopId', 'name')
      .populate('category', 'name');
    res.json(products);
  } catch (error) {
    next(error);
  }
});

// PROD-05: Product categorization & attributes - MUST come before /:id route
router.get('/categories', async (req, res, next) => {
  try {
    // This would come from Category model
    res.json([]);
  } catch (error) {
    next(error);
  }
});

router.get('/attributes', async (req, res, next) => {
  try {
    // This would come from Attribute model
    res.json([]);
  } catch (error) {
    next(error);
  }
});

// PROD-08: Product detail page (Customer)
router.get('/:id', async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id)
      .populate('category', 'name')
      .populate('shopId', 'name');

    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    res.json(product);
  } catch (error) {
    next(error);
  }
});

// PROD-01: Create product (Shop)
router.post('/', authenticate, authorize('shop', 'admin'), async (req, res, next) => {
  try {
    // Get shop info to check restrictions
    const shop = await Shop.findById(req.user.shopId);
    
    // Restriction: Team Cherry can only create products for Hollow Knight and Silksong
    if (shop && shop.name === 'Team Cherry' && req.body.collectionId) {
      const allowedCollections = ['hollow-knight', 'silksong'];
      if (!allowedCollections.includes(req.body.collectionId)) {
        return res.status(403).json({
          error: true,
          message: 'Team Cherry can only create products for Hollow Knight and Silksong collections',
          code: 'COLLECTION_RESTRICTED'
        });
      }
    }
    
    // Create product data, ensuring required fields are present
    const productData = {
      ...req.body,
      shopId: req.user.shopId || req.body.shopId,
      status: req.body.status || 'pending'
    };
    
    // If category is not provided, we'll skip it (it's now optional)
    // In production, you might want to create a default category
    
    const product = new Product(productData);
    await product.save();
    res.status(201).json(product);
  } catch (error) {
    next(error);
  }
});

// PROD-02: Edit product details (Shop)
router.put('/:id', authenticate, authorize('shop', 'admin'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    // Check ownership
    if (req.user.role === 'shop' && product.shopId.toString() !== req.user.shopId?.toString()) {
      return res.status(403).json({
        error: true,
        message: 'Not authorized',
        code: 'FORBIDDEN'
      });
    }

    // Get shop info to check restrictions
    const shop = await Shop.findById(req.user.shopId);
    
    // Restriction: Team Cherry can only create products for Hollow Knight and Silksong
    if (shop && shop.name === 'Team Cherry' && req.body.collectionId) {
      const allowedCollections = ['hollow-knight', 'silksong'];
      if (!allowedCollections.includes(req.body.collectionId)) {
        return res.status(403).json({
          error: true,
          message: 'Team Cherry can only create products for Hollow Knight and Silksong collections',
          code: 'COLLECTION_RESTRICTED'
        });
      }
    }

    Object.assign(product, req.body);
    await product.save();
    res.json(product);
  } catch (error) {
    next(error);
  }
});

// PROD-03: Delete/disable product (Shop)
router.delete('/:id', authenticate, authorize('shop', 'admin'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    if (req.user.role === 'shop' && product.shopId.toString() !== req.user.shopId?.toString()) {
      return res.status(403).json({
        error: true,
        message: 'Not authorized',
        code: 'FORBIDDEN'
      });
    }

    await product.deleteOne();
    res.json({ message: 'Product deleted successfully' });
  } catch (error) {
    next(error);
  }
});

router.patch('/:id/disable', authenticate, authorize('shop', 'admin'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    product.status = 'inactive';
    await product.save();
    res.json(product);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id/approve', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    product.status = 'approved';
    await product.save();
    res.json(product);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id/reject', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    product.status = 'rejected';
    await product.save();
    res.json(product);
  } catch (error) {
    next(error);
  }
});


// PROD-06: Product image upload & management
router.post('/:id/images', authenticate, authorize('shop', 'admin'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    // In production, handle file upload with multer
    const imageUrl = req.body.imageUrl || '/placeholder.jpg';
    product.images.push(imageUrl);
    await product.save();
    
    res.json({ imageUrl });
  } catch (error) {
    next(error);
  }
});

router.delete('/:id/images/:imageId', authenticate, authorize('shop', 'admin'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    product.images = product.images.filter(img => img !== req.params.imageId);
    await product.save();
    res.json({ message: 'Image deleted successfully' });
  } catch (error) {
    next(error);
  }
});

export default router;

