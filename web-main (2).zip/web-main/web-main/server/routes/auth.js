import express from 'express';
import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import Shop from '../models/Shop.js';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();
const JWT_SECRET = process.env.JWT_SECRET || 'collab-nexus-super-secret-jwt-key-2025-production';

// AUTH-01: User registration (Customer, Shop)
router.post('/register', async (req, res, next) => {
  try {
    const { name, email, password, company, notes, role = 'customer' } = req.body;

    // Check if user exists
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({
        error: true,
        message: 'User already exists',
        code: 'USER_EXISTS'
      });
    }

    // Create user
    const user = new User({
      name,
      email,
      password,
      role,
      company,
      status: 'active'
    });

    await user.save();

    // If shop role, create shop
    if (role === 'shop') {
      const shop = new Shop({
        name: company || name,
        email,
        ownerId: user._id,
        status: 'pending'
      });
      await shop.save();
      user.shopId = shop._id;
      await user.save();
    }

    // Generate token
    const token = jwt.sign(
      { userId: user._id, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(201).json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        shopId: user.shopId
      }
    });
  } catch (error) {
    next(error);
  }
});

// AUTH-02: User login/logout
router.post('/login', async (req, res, next) => {
  try {
    const { email, password, role } = req.body;

    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({
        error: true,
        message: 'Invalid credentials',
        code: 'INVALID_CREDENTIALS'
      });
    }

    // Check role if specified
    if (role && user.role !== role) {
      return res.status(403).json({
        error: true,
        message: 'Invalid role',
        code: 'INVALID_ROLE'
      });
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      return res.status(401).json({
        error: true,
        message: 'Invalid credentials',
        code: 'INVALID_CREDENTIALS'
      });
    }

    if (user.status === 'blocked') {
      return res.status(403).json({
        error: true,
        message: 'Account is blocked',
        code: 'ACCOUNT_BLOCKED'
      });
    }

    const token = jwt.sign(
      { userId: user._id, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
        shopId: user.shopId
      }
    });
  } catch (error) {
    next(error);
  }
});

router.post('/logout', authenticate, async (req, res) => {
  // In a stateless JWT system, logout is handled client-side
  // But we can add token blacklisting here if needed
  res.json({ message: 'Logged out successfully' });
});

// AUTH-03: Password reset & email verification
router.post('/password-reset/request', async (req, res, next) => {
  try {
    const { email } = req.body;
    const user = await User.findOne({ email });
    
    if (!user) {
      // Don't reveal if user exists for security
      return res.json({ message: 'If the email exists, a reset link has been sent' });
    }

    // In production, send email with reset token
    // For now, just return success
    res.json({ message: 'Password reset email sent' });
  } catch (error) {
    next(error);
  }
});

router.post('/password-reset/confirm', async (req, res, next) => {
  try {
    const { token, newPassword } = req.body;
    
    // In production, verify token and update password
    // For now, simplified version
    res.json({ message: 'Password reset successfully' });
  } catch (error) {
    next(error);
  }
});

router.post('/verify-email', async (req, res, next) => {
  try {
    const { token } = req.body;
    
    // In production, verify email token
    // For now, simplified version
    res.json({ message: 'Email verified successfully' });
  } catch (error) {
    next(error);
  }
});

// AUTH-06: Session management & security validation
router.get('/validate', authenticate, async (req, res) => {
  res.json({
    user: {
      id: req.user._id,
      name: req.user.name,
      email: req.user.email,
      role: req.user.role,
      shopId: req.user.shopId,
      permissions: req.user.permissions
    }
  });
});

export default router;

