import express from 'express';
import Order from '../models/Order.js';
import Product from '../models/Product.js';
import User from '../models/User.js';
import Shop from '../models/Shop.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// RPT-01: Sales reports (Shop)
router.get('/sales', authenticate, authorize('shop'), async (req, res, next) => {
  try {
    const orders = await Order.find({ shopId: req.user.shopId });
    const totalSales = orders.reduce((sum, order) => sum + order.total, 0);
    const totalOrders = orders.length;
    
    res.json({
      totalSales,
      totalOrders,
      period: req.query.from && req.query.to ? { from: req.query.from, to: req.query.to } : null
    });
  } catch (error) {
    next(error);
  }
});

// RPT-02: Order & customer reports
router.get('/orders', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const orders = await Order.find().populate('customerId', 'name');
    res.json(orders);
  } catch (error) {
    next(error);
  }
});

router.get('/customers', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const customers = await User.find({ role: 'customer' });
    res.json(customers);
  } catch (error) {
    next(error);
  }
});

// RPT-03: System activity reports (Admin)
router.get('/activity', authenticate, authorize('admin'), async (req, res) => {
  res.json([]);
});

// RPT-04: Export reports
router.get('/:type/export', authenticate, authorize('admin'), async (req, res) => {
  // In production, generate CSV/PDF
  res.json({ message: 'Export functionality to be implemented' });
});

// RPT-05: Dashboard overview (Admin)
router.get('/dashboard', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const [totalOrders, totalCustomers, activeShops] = await Promise.all([
      Order.countDocuments(),
      User.countDocuments({ role: 'customer' }),
      Shop.countDocuments({ status: 'active' })
    ]);

    const orders = await Order.find();
    const totalRevenue = orders.reduce((sum, order) => sum + order.total, 0);

    res.json({
      totalRevenue,
      totalOrders,
      activeShops,
      totalCustomers
    });
  } catch (error) {
    next(error);
  }
});

export default router;

