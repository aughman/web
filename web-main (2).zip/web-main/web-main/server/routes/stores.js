import express from 'express';
import Shop from '../models/Shop.js';
import User from '../models/User.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// STORE-01: Create shop profile (Admin)
router.post('/', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const shop = new Shop({
      ...req.body,
      status: 'pending'
    });
    await shop.save();
    res.status(201).json(shop);
  } catch (error) {
    next(error);
  }
});

// STORE-02: Edit shop information (Admin)
router.put('/:id', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const shop = await Shop.findById(req.params.id);
    if (!shop) {
      return res.status(404).json({
        error: true,
        message: 'Shop not found',
        code: 'SHOP_NOT_FOUND'
      });
    }

    Object.assign(shop, req.body);
    await shop.save();
    res.json(shop);
  } catch (error) {
    next(error);
  }
});

// STORE-03: Activate / deactivate shop
router.patch('/:id/activate', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const shop = await Shop.findById(req.params.id);
    if (!shop) {
      return res.status(404).json({
        error: true,
        message: 'Shop not found',
        code: 'SHOP_NOT_FOUND'
      });
    }

    shop.status = 'active';
    await shop.save();
    res.json(shop);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id/deactivate', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const shop = await Shop.findById(req.params.id);
    if (!shop) {
      return res.status(404).json({
        error: true,
        message: 'Shop not found',
        code: 'SHOP_NOT_FOUND'
      });
    }

    shop.status = 'inactive';
    await shop.save();
    res.json(shop);
  } catch (error) {
    next(error);
  }
});

// STORE-04: View shop performance summary
router.get('/:id/performance', authenticate, async (req, res, next) => {
  try {
    const shop = await Shop.findById(req.params.id);
    if (!shop) {
      return res.status(404).json({
        error: true,
        message: 'Shop not found',
        code: 'SHOP_NOT_FOUND'
      });
    }

    // In production, calculate performance metrics
    res.json({
      totalSales: 0,
      totalOrders: 0,
      totalProducts: 0
    });
  } catch (error) {
    next(error);
  }
});

// STORE-05: Shop self-profile management
router.get('/profile', authenticate, authorize('shop'), async (req, res, next) => {
  try {
    const shop = await Shop.findById(req.user.shopId);
    if (!shop) {
      return res.status(404).json({
        error: true,
        message: 'Shop not found',
        code: 'SHOP_NOT_FOUND'
      });
    }
    res.json(shop);
  } catch (error) {
    next(error);
  }
});

router.put('/profile', authenticate, authorize('shop'), async (req, res, next) => {
  try {
    const shop = await Shop.findById(req.user.shopId);
    if (!shop) {
      return res.status(404).json({
        error: true,
        message: 'Shop not found',
        code: 'SHOP_NOT_FOUND'
      });
    }

    Object.assign(shop, req.body);
    await shop.save();
    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    next(error);
  }
});

// STORE-06: Shop verification / approval workflow
router.get('/pending', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const shops = await Shop.find({ status: 'pending' })
      .populate('ownerId', 'name email');
    res.json(shops);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id/approve', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const shop = await Shop.findById(req.params.id);
    if (!shop) {
      return res.status(404).json({
        error: true,
        message: 'Shop not found',
        code: 'SHOP_NOT_FOUND'
      });
    }

    shop.status = 'approved';
    shop.verificationStatus = 'verified';
    await shop.save();
    res.json(shop);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id/reject', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const shop = await Shop.findById(req.params.id);
    if (!shop) {
      return res.status(404).json({
        error: true,
        message: 'Shop not found',
        code: 'SHOP_NOT_FOUND'
      });
    }

    shop.status = 'rejected';
    await shop.save();
    res.json(shop);
  } catch (error) {
    next(error);
  }
});

export default router;

