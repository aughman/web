import express from 'express';
import { authenticate } from '../middleware/auth.js';

const router = express.Router();

// NOTI-01-05: Notification system
router.get('/', authenticate, async (req, res) => {
  res.json([]);
});

router.get('/unread-count', authenticate, async (req, res) => {
  res.json({ unread: 0 });
});

router.patch('/:id/read', authenticate, async (req, res) => {
  res.json({ message: 'Notification marked as read' });
});

router.patch('/read-all', authenticate, async (req, res) => {
  res.json({ message: 'All notifications marked as read' });
});

export default router;

