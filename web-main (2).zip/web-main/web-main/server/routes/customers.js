import express from 'express';
import User from '../models/User.js';
import Order from '../models/Order.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// CUST-01: Customer profile management
router.get('/profile', authenticate, authorize('customer'), async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id).select('-password');
    res.json(user);
  } catch (error) {
    next(error);
  }
});

router.put('/profile', authenticate, authorize('customer'), async (req, res, next) => {
  try {
    const user = await User.findById(req.user._id);
    Object.assign(user, req.body);
    await user.save();
    res.json({ message: 'Profile updated successfully' });
  } catch (error) {
    next(error);
  }
});

// CUST-02: Admin view/edit customer information
router.get('/admin', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const { search, status, limit = 50, offset = 0 } = req.query;
    const query = { role: 'customer' };

    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } }
      ];
    }
    if (status) query.status = status;

    const customers = await User.find(query)
      .select('-password')
      .limit(parseInt(limit))
      .skip(parseInt(offset))
      .sort({ createdAt: -1 });

    res.json(customers);
  } catch (error) {
    next(error);
  }
});

router.get('/:id', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const customer = await User.findById(req.params.id).select('-password');
    if (!customer) {
      return res.status(404).json({
        error: true,
        message: 'Customer not found',
        code: 'CUSTOMER_NOT_FOUND'
      });
    }
    res.json(customer);
  } catch (error) {
    next(error);
  }
});

router.put('/:id', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const customer = await User.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({
        error: true,
        message: 'Customer not found',
        code: 'CUSTOMER_NOT_FOUND'
      });
    }

    Object.assign(customer, req.body);
    await customer.save();
    res.json({ message: 'Customer updated successfully' });
  } catch (error) {
    next(error);
  }
});

// CUST-03: Customer order history
router.get('/:id/orders', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const orders = await Order.find({ customerId: req.params.id })
      .populate('shopId', 'name')
      .sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    next(error);
  }
});

// CUST-04: Account status management (active/blocked)
router.patch('/:id/status', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const customer = await User.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({
        error: true,
        message: 'Customer not found',
        code: 'CUSTOMER_NOT_FOUND'
      });
    }

    customer.status = req.body.status;
    await customer.save();
    res.json({ message: 'Status updated successfully' });
  } catch (error) {
    next(error);
  }
});

export default router;

