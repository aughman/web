import express from 'express';
import Product from '../models/Product.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// INV-01: Inventory setup per product
router.post('/products/:id', authenticate, authorize('shop'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    product.stock = req.body;
    await product.save();
    res.json({ message: 'Inventory setup successfully' });
  } catch (error) {
    next(error);
  }
});

// INV-02: Stock quantity update on order
router.post('/orders/:id/update-stock', authenticate, async (req, res, next) => {
  try {
    // In production, update stock when order is confirmed
    res.json({ message: 'Stock updated' });
  } catch (error) {
    next(error);
  }
});

// INV-04: Inventory adjustment (Shop)
router.post('/products/:id/adjust', authenticate, authorize('shop'), async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id);
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }

    product.stock.quantity = req.body.quantity;
    await product.save();
    res.json({ message: 'Inventory adjusted successfully' });
  } catch (error) {
    next(error);
  }
});

// INV-05: Inventory reporting (Admin)
router.get('/reports', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const products = await Product.find()
      .select('name stock')
      .populate('shopId', 'name');
    
    const report = products.map(p => ({
      productId: p._id,
      productName: p.name,
      quantity: p.stock.quantity,
      lowStock: p.stock.quantity <= p.stock.lowStockThreshold
    }));

    res.json(report);
  } catch (error) {
    next(error);
  }
});

// INV-06: Shop inventory reporting (Shop) - MUST come before /products/:id route
router.get('/shop/reports', authenticate, authorize('shop'), async (req, res, next) => {
  try {
    if (!req.user.shopId) {
      return res.status(403).json({
        error: true,
        message: 'Shop account not linked to a shop',
        code: 'SHOP_NOT_LINKED'
      });
    }

    const products = await Product.find({ shopId: req.user.shopId })
      .select('name stock');
    
    const report = products.map(p => ({
      productId: p._id,
      productName: p.name,
      quantity: p.stock?.quantity || 0,
      lowStock: (p.stock?.quantity || 0) <= (p.stock?.lowStockThreshold || 10)
    }));

    res.json(report);
  } catch (error) {
    next(error);
  }
});

router.get('/alerts/low-stock', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const products = await Product.find({
      $expr: { $lte: ['$stock.quantity', '$stock.lowStockThreshold'] }
    });
    res.json(products);
  } catch (error) {
    next(error);
  }
});

router.get('/products/:id', authenticate, async (req, res, next) => {
  try {
    const product = await Product.findById(req.params.id).select('stock name');
    if (!product) {
      return res.status(404).json({
        error: true,
        message: 'Product not found',
        code: 'PRODUCT_NOT_FOUND'
      });
    }
    res.json(product);
  } catch (error) {
    next(error);
  }
});

export default router;

