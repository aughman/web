import express from 'express';
import Order from '../models/Order.js';
import { authenticate, authorize } from '../middleware/auth.js';

const router = express.Router();

// ORD-01: Create order (Customer)
router.post('/', authenticate, authorize('customer'), async (req, res, next) => {
  try {
    const order = new Order({
      ...req.body,
      customerId: req.user._id
    });
    await order.save();
    res.status(201).json(order);
  } catch (error) {
    next(error);
  }
});

// ORD-02: View order history (Customer)
router.get('/customer', authenticate, authorize('customer'), async (req, res, next) => {
  try {
    const orders = await Order.find({ customerId: req.user._id })
      .populate('shopId', 'name')
      .sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    next(error);
  }
});

// ORD-03: Order status tracking (Customer)
router.get('/:id/status', authenticate, async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        error: true,
        message: 'Order not found',
        code: 'ORDER_NOT_FOUND'
      });
    }

    // Check authorization
    if (req.user.role === 'customer' && order.customerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        error: true,
        message: 'Not authorized',
        code: 'FORBIDDEN'
      });
    }

    res.json({ status: order.status, updatedAt: order.updatedAt });
  } catch (error) {
    next(error);
  }
});

router.get('/:id/track', authenticate, async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id)
      .populate('shippingId');
    
    if (!order) {
      return res.status(404).json({
        error: true,
        message: 'Order not found',
        code: 'ORDER_NOT_FOUND'
      });
    }

    res.json({
      status: order.status,
      shipping: order.shippingId
    });
  } catch (error) {
    next(error);
  }
});

// ORD-04: View & process orders (Shop)
router.get('/shop', authenticate, authorize('shop'), async (req, res, next) => {
  try {
    const orders = await Order.find({ shopId: req.user.shopId })
      .populate('customerId', 'name email')
      .sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id/process', authenticate, authorize('shop'), async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        error: true,
        message: 'Order not found',
        code: 'ORDER_NOT_FOUND'
      });
    }

    if (order.shopId.toString() !== req.user.shopId?.toString()) {
      return res.status(403).json({
        error: true,
        message: 'Not authorized',
        code: 'FORBIDDEN'
      });
    }

    const { action } = req.body;
    if (action === 'confirm') order.status = 'confirmed';
    if (action === 'ship') order.status = 'shipped';
    
    await order.save();
    res.json(order);
  } catch (error) {
    next(error);
  }
});

// ORD-05: Update order status
router.patch('/:id/status', authenticate, authorize('shop', 'admin'), async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        error: true,
        message: 'Order not found',
        code: 'ORDER_NOT_FOUND'
      });
    }

    order.status = req.body.status;
    if (req.body.notes) order.notes = req.body.notes;
    await order.save();
    res.json(order);
  } catch (error) {
    next(error);
  }
});

// ORD-06: Admin order overview & intervention
router.get('/admin', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const orders = await Order.find()
      .populate('customerId', 'name email')
      .populate('shopId', 'name')
      .sort({ createdAt: -1 });
    res.json(orders);
  } catch (error) {
    next(error);
  }
});

router.patch('/:id/intervene', authenticate, authorize('admin'), async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        error: true,
        message: 'Order not found',
        code: 'ORDER_NOT_FOUND'
      });
    }

    const { action, reason } = req.body;
    if (action === 'cancel') {
      order.status = 'cancelled';
      order.cancellationReason = reason;
    }
    
    await order.save();
    res.json(order);
  } catch (error) {
    next(error);
  }
});

// ORD-07: Order cancellation & refund handling
router.patch('/:id/cancel', authenticate, async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        error: true,
        message: 'Order not found',
        code: 'ORDER_NOT_FOUND'
      });
    }

    // Check authorization
    if (req.user.role === 'customer' && order.customerId.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        error: true,
        message: 'Not authorized',
        code: 'FORBIDDEN'
      });
    }

    order.status = 'cancelled';
    order.cancellationReason = req.body.reason;
    await order.save();
    res.json(order);
  } catch (error) {
    next(error);
  }
});

router.post('/:id/refund', authenticate, async (req, res, next) => {
  try {
    const order = await Order.findById(req.params.id);
    if (!order) {
      return res.status(404).json({
        error: true,
        message: 'Order not found',
        code: 'ORDER_NOT_FOUND'
      });
    }

    // In production, process refund through payment gateway
    res.json({ message: 'Refund request submitted' });
  } catch (error) {
    next(error);
  }
});

export default router;

